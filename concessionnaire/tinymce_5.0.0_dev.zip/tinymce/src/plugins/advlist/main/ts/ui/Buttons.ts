/**
 * Copyright (c) Tiny Technologies, Inc. All rights reserved.
 * Licensed under the LGPL or a commercial license.
 * For LGPL see License.txt in the project root for license information.
 * For commercial licenses see https://www.tiny.cloud/
 */

import Tools from 'tinymce/core/api/util/Tools';
import Settings from '../api/Settings';
import Actions from '../core/Actions';
import ListUtils from '../core/ListUtils';
import { Editor } from '../../../../../core/main/ts/api/Editor';

const enum ListType {
  OrderedList = 'OL',
  UnorderedList = 'UL'
}

const findIndex = function (list, predicate) {
  for (let index = 0; index < list.length; index++) {
    const element = list[index];

    if (predicate(element)) {
      return index;
    }
  }
  return -1;
};

// <ListStyles>
const styleValueToText = function (styleValue) {
  return styleValue.replace(/\-/g, ' ').replace(/\b\w/g, function (chr) {
    return chr.toUpperCase();
  });
};

const isWithinList = (editor: Editor, e, nodeName) => {
  const tableCellIndex = findIndex(e.parents, ListUtils.isTableCellNode);
  const parents = tableCellIndex !== -1 ? e.parents.slice(0, tableCellIndex) : e.parents;
  const lists = Tools.grep(parents, ListUtils.isListNode(editor));
  return lists.length > 0 && lists[0].nodeName === nodeName;
};

const addSplitButton = function (editor: Editor, id, tooltip, cmd, nodeName, styles) {
  editor.ui.registry.addSplitButton(id, {
    tooltip,
    icon: nodeName === ListType.OrderedList ? 'ordered-list' : 'unordered-list',
    presets: 'toolbar',
    columns: 3,
    fetch: (callback) => {
      const items = Tools.map(styles, (styleValue) => {
        const iconStyle = nodeName === ListType.OrderedList ? 'num' : 'bull';
        const iconName = styleValue === 'disc' || styleValue === 'decimal' ? 'default' : styleValue;
        const itemValue = styleValue === 'default' ? '' : styleValue;
        const displayText = styleValueToText(styleValue);
        return {
          type: 'choiceitem',
          value: itemValue,
          icon: 'list-' +  iconStyle + '-' + iconName,
          text: displayText,
          ariaLabel: displayText
        };
      });
      callback(items);
    },
    onAction: () => editor.execCommand(cmd),
    onItemAction: (splitButtonApi, value) => {
      Actions.applyListFormat(editor, nodeName, value);
    },
    select: (value) => {
      const listStyleType = ListUtils.getSelectedStyleType(editor);
      return listStyleType.map((listStyle) => {
        return value === listStyle;
      }).getOr(false);
    },
    onSetup: (api) => {
      const nodeChangeHandler = (e) => {
        api.setActive(isWithinList(editor, e, nodeName));
      };
      editor.on('nodeChange', nodeChangeHandler);

      return () => editor.off('nodeChange', nodeChangeHandler);
    }
  });
};

const addButton = function (editor: Editor, id, tooltip, cmd, nodeName, styles) {
  editor.ui.registry.addToggleButton(id, {
    active: false,
    tooltip,
    icon: nodeName === ListType.OrderedList ? 'ordered-list' : 'unordered-list',
    onSetup: (api) => {
      const nodeChangeHandler = (e) => {
        api.setActive(isWithinList(editor, e, nodeName));
      };
      editor.on('nodeChange', nodeChangeHandler);

      return () => editor.off('nodeChange', nodeChangeHandler);
    },
    onAction: () => editor.execCommand(cmd)
  });
};

const addControl = function (editor, id, tooltip, cmd, nodeName, styles) {
  if (styles.length > 0) {
    addSplitButton(editor, id, tooltip, cmd, nodeName, styles);
  } else {
    addButton(editor, id, tooltip, cmd, nodeName, styles);
  }
};

const register = function (editor) {
  addControl(editor, 'numlist', 'Numbered list', 'InsertOrderedList', ListType.OrderedList, Settings.getNumberStyles(editor));
  addControl(editor, 'bullist', 'Bullet list', 'InsertUnorderedList', ListType.UnorderedList, Settings.getBulletStyles(editor));
};

export default {
  register
};